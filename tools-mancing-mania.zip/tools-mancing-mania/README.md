# Tools

![Tak berjudul27_20240509165656](https://github.com/andixax/tools/assets/168948944/53741884-5e0e-4ee0-afdd-5940c3212cfc)


# Cara Menjalan Kan

##
<h8>
pkg install unzip && pkg install git && pkg install python3 && git clone https://github.com/andixax/tools && cd tools && unzip a.zip && python3 run.py
</h8>
